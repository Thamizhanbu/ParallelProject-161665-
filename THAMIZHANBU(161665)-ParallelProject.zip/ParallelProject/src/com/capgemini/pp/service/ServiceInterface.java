package com.capgemini.pp.service;

import java.util.List;
import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.exception.BankAccountException;

public interface ServiceInterface {
    public boolean createAccount(Customer c) throws BankAccountException;
    public double showBalance(long accnum) throws BankAccountException;
    public Customer customerDetails(Long accnum) throws BankAccountException;
    public double deposit(long accnum,double amount) throws BankAccountException;
    public double withdraw(long accnum, double amount)  throws BankAccountException;
    public String fundTransfer(long accnum,long accnum2, double amount) throws BankAccountException;
    public String printTransaction(long accnum) throws BankAccountException;
    public List<Customer> getAllCustomers() throws BankAccountException;
    
}
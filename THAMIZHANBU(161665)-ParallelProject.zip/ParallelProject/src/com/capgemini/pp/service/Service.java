package com.capgemini.pp.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.dao.*;
import com.capgemini.pp.exception.BankAccountException;

public class Service implements ServiceInterface {
	   
    Dao d=null;
    double check;
    
    public int validateAccountNumber(Long accnum){
    	d=new Dao();
		return d.validateAccountNumber(accnum);
    	
    }
    public boolean validateName(String name2) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
    Matcher nameMatch=name.matcher(name2);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAge(int age) throws BankAccountException
    {
    boolean flag=false;
    if(age>=18&&age<=60)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAddress(String address) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("(?=,*[0-9])[A-Za-z0-9,\\s]+");
    Matcher nameMatch=name.matcher(address);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }

    
    public boolean validateNum(String mobnum) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[0-9]{10}");
    Matcher nameMatch=name.matcher(mobnum);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAadhaar(String aadhaar) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[0-9]{12}");
    Matcher nameMatch=name.matcher(aadhaar);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    
    public boolean validatePan(String pan) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[A-Z0-9]{10}");
    Matcher nameMatch=name.matcher(pan);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    

    
    public boolean validateBalance(double balance) throws BankAccountException
    {
    boolean flag=false;
    if(balance>=0)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    public boolean createAccount(Customer c) throws BankAccountException {
       d=new Dao();
       return d.createAccount(c);
    }


    
    public Customer customerDetails(Long accnum) throws BankAccountException {
    	Customer c2=null;
    	d=new Dao();
    	c2=d.customerDetails(accnum);
        return c2;
    }


    public double showBalance(long accnum) throws BankAccountException {
    	d=new Dao();
        double bal = 0;    
        bal = d.showBalance(accnum);
      return bal;
    }
    
    public double deposit(long accnum,double amount) throws BankAccountException{
    	d=new Dao();
        double dep = 0;
        Customer c4= d.customerDetails(accnum);
             dep = c4.getBalance() + amount;
             c4.setBalance(dep); 
             String s1 =c4.getTransaction().concat("\n"+amount+" is Deposited");
             c4.setTransaction(s1);          
      return d.deposit(c4);

    }
    
    
    public double withdraw(long accnum, double amount) throws BankAccountException{
    	d=new Dao();
        double wd = 0;
        

        Customer c5= d.customerDetails(accnum);
        if (amount<=c5.getBalance() ) {
            wd = c5.getBalance() - amount;
            c5.setBalance(wd);
            String s2 =c5.getTransaction().concat("\n"+amount+" is Withdrawn");
            c5.setTransaction(s2);
            return d.withdraw(c5);
        }
        else
        {
          throw new BankAccountException("Invalid amount");
        }

    }
    
    public String fundTransfer(long accnum,long accnum2, double amount) throws BankAccountException  {
        
    	d=new Dao();
        String fund=null;
        double b1=0,b2=0;
        boolean res1,res2;
        b1=withdraw(accnum,amount);
        if(b1!=0) {
            b2=deposit(accnum2,amount);
            fund="After the fund transfer:\n Balance in the source account is "+b1+
                    " \n Balance in the destination account is "+b2;
            
            Customer sa=d.customerDetails(accnum);
            String s1=sa.getTransaction().concat("\nThis last transaction of amount "+amount+"is transferred from your account ("+accnum+") to "+" the account of "+accnum2);
            sa.setTransaction(s1);
            res1=d.fundTransfer(sa);
            
            Customer da=d.customerDetails(accnum2);
            String s2=da.getTransaction().concat("\nThis last transaction of amount "+amount+"is transferred from the account of "+accnum+" to "+" your account ("+accnum2)+")";
            da.setTransaction(s2);
            res2=d.fundTransfer(da);
            
            if(res1==true&&res2==true){
            	return fund;
            }
            else
            {
            	return "fund transfer not added";
            }
            
        }

       else
        {
            return "Transfer failed";
        }
    }
    
    public String printTransaction(long accnum) throws BankAccountException{

    	Customer c6=d.printTransaction(accnum);	
    	 return c6.getTransaction();
    }

    
	@Override
	public List<Customer> getAllCustomers() throws BankAccountException {
		d=new Dao();
		return d.getAllCustomers();
	}
    
}
package com.capgemini.pp.exception;

public class BankAccountException extends Exception {

    public BankAccountException(String msg) {
        
        super(msg);
    }
}

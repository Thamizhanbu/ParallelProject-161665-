package com.capgemini.pp.dao;


import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.exception.BankAccountException;
import com.capgemini.pp.utility.JPAUtil;

public class Dao implements DaoInterface {
	private EntityManager entityManager;
	
	
	public int validateAccountNumber(Long accnum){
		
		entityManager=JPAUtil.getEntityManager();
		Customer c=entityManager.find(Customer.class, accnum);
		if(c==null)
		{
			return 0;
		}
		else
		{
		return 1;
	}
	}
	
	
	

	@Override
	public boolean createAccount(Customer c) throws BankAccountException {
		EntityManager entityManager = null;	
		try{
			boolean result=false;
			entityManager=JPAUtil.getEntityManager();
			EntityTransaction transaction=entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(c);
			transaction.commit();
	        result=true;
	        return result;
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
	
	
	
	@Override
	public Customer customerDetails(Long accnum) throws BankAccountException {
		try{

			entityManager=JPAUtil.getEntityManager();
			Customer c=entityManager.find(Customer.class, accnum);
			return c;
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
	
	
	@Override
	public double showBalance(long accnum) throws BankAccountException {
		try{
			entityManager=JPAUtil.getEntityManager();
			Customer c=entityManager.find(Customer.class, accnum);
			return c.getBalance();
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
		
	@Override 
	public double deposit(Customer c) throws BankAccountException{
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(c);
			entityManager.getTransaction().commit();
			return c.getBalance();
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}
	
	@Override public double withdraw(Customer c) throws BankAccountException{
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(c);
			entityManager.getTransaction().commit();
			return c.getBalance();
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}
	
	
	@Override
	public boolean fundTransfer(Customer c) throws BankAccountException {
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(c);
			entityManager.getTransaction().commit();
			return true;
			
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}




	@Override
	public Customer printTransaction(long accnum) throws BankAccountException {
		try{

			entityManager=JPAUtil.getEntityManager();
			Customer c=entityManager.find(Customer.class, accnum);
			return c;
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
	
	
	
	@Override
	public List<Customer> getAllCustomers() throws BankAccountException {
		try{
			entityManager=JPAUtil.getEntityManager();
			Query query=entityManager.createQuery("from Customer");
			List<Customer> employeeList=query.getResultList();
			return employeeList;
		}
		catch(PersistenceException e){
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	
}
	


	    
}